import asyncio
import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy import select
from src.data.models.postgres.scheduler_settings import SchedulerSettings
from src.data.clients.postgres_client import AsyncSessionLocal
from src.core.services.aging_service import get_overdue_invoices_with_bucket
from src.core.services.reminder_service import process_reminder

logger = logging.getLogger(__name__)
scheduler = AsyncIOScheduler()
JOB_ID = "aging_reminder_job"


async def run_aging_and_reminders():
    """
    Core job logic — must be called from within an async context.
    Uses a fresh AsyncSession per run to avoid greenlet issues.
    """
    try:
        async with AsyncSessionLocal() as db:
            overdue_items = await get_overdue_invoices_with_bucket(db)
            if not overdue_items:
                logger.info("Aging job: no overdue invoices found.")
                return
            generated = skipped = failed = 0
            for item in overdue_items:
                try:
                    reminder = await process_reminder(
                        item["invoice"], item["days_overdue"], item["config"], db
                    )
                    if reminder is None:
                        skipped += 1
                    elif reminder.status == "SENT":
                        generated += 1
                    else:
                        failed += 1
                except Exception as e:
                    logger.error(
                        "process_reminder failed for invoice %s: %s",
                        item["invoice"].id, e, exc_info=True,
                    )
                    failed += 1
            logger.info(
                "Aging job done — sent: %d, skipped: %d, failed: %d",
                generated, skipped, failed,
            )
    except Exception as e:
        logger.error("Aging job failed: %s", e, exc_info=True)
        raise


def _job_wrapper():
    """
    Sync wrapper that APScheduler calls in the event loop.
    Schedules the coroutine onto the running asyncio loop.
    """
    loop = asyncio.get_event_loop()
    if loop.is_running():
        asyncio.ensure_future(run_aging_and_reminders())
    else:
        loop.run_until_complete(run_aging_and_reminders())


async def reschedule_aging_job(hour: int, minute: int):
    """Safe reschedule — adds the job if it doesn't exist yet."""
    trigger = CronTrigger(hour=hour, minute=minute)
    if scheduler.get_job(JOB_ID):
        scheduler.reschedule_job(job_id=JOB_ID, trigger=trigger)
        logger.info("Aging job rescheduled to %02d:%02d", hour, minute)
    else:
        scheduler.add_job(
            run_aging_and_reminders,   # AsyncIOScheduler handles coroutines natively
            trigger=trigger,
            id=JOB_ID,
            replace_existing=True,
            misfire_grace_time=3600,
        )
        logger.info("Aging job added at %02d:%02d", hour, minute)


async def start_scheduler_from_db():
    hour, minute = 9, 0
    async with AsyncSessionLocal() as db:
        result = await db.execute(
            select(SchedulerSettings).where(SchedulerSettings.id == 1)
        )
        settings = result.scalar_one_or_none()
        if settings and settings.is_enabled:
            hour   = settings.run_hour
            minute = settings.run_minute
            logger.info("Scheduler: loaded time %02d:%02d from DB", hour, minute)
        else:
            logger.info("Scheduler: no settings found, defaulting to 09:00")

    await reschedule_aging_job(hour, minute)
    if not scheduler.running:
        scheduler.start()
        logger.info("APScheduler started.")


def stop_scheduler():
    if scheduler.running:
        scheduler.shutdown()
        logger.info("APScheduler stopped.")